import { getStore } from "@netlify/blobs";

const DURATION_MS = 5 * 60 * 1000;

export default async (request) => {
  const url = new URL(request.url);
  const token = url.searchParams.get("token");
  if (!token || !/^[a-f0-9-]{20,80}$/i.test(token)) {
    return new Response("Missing or invalid temporary-link token.", { status: 400 });
  }

  const store = getStore("savvyaze-temporary-links");
  const key = `token:${token}`;
  let record = await store.get(key, { type: "json" });

  if (!record) {
    record = { firstOpenedAt: Date.now() };
    await store.setJSON(key, record);
  }

  const remaining = record.firstOpenedAt + DURATION_MS - Date.now();
  if (remaining <= 0) {
    return new Response("This link has expired.", {
      status: 410,
      headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" }
    });
  }

  return new Response(JSON.stringify({
    active: true,
    expiresAt: new Date(record.firstOpenedAt + DURATION_MS).toISOString(),
    remainingMs: remaining
  }), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    }
  });
};

export const config = { path: "/api/check-expiry" };
